<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Bush_No2" tilewidth="16" tileheight="16" tilecount="1" columns="1">
 <image source="Bush_No2.png" width="16" height="16"/>
 <tile id="0">
  <objectgroup draworder="index" id="3">
   <object id="2" x="0.727273" y="2.54545">
    <polygon points="0,0 4.18182,-2.18182 10.3636,-2.36364 13.8182,0.727273 14.9091,3.45455 15.2727,8.54545 11.2727,12.3636 3.63636,12.3636 0.363636,10.5455 -1.09091,8"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
