<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="chest_01" tilewidth="16" tileheight="16" tilecount="4" columns="4">
 <image source="chest_01.png" width="64" height="16"/>
</tileset>
