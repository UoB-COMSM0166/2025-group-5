<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="plains" tilewidth="16" tileheight="16" tilecount="72" columns="6">
 <image source="plains.png" width="96" height="192"/>
</tileset>
