<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="flower sheet" tilewidth="16" tileheight="16" tilecount="484" columns="22">
 <image source="flower sheet.png" width="352" height="352"/>
</tileset>
