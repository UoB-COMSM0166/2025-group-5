<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="tileset-pixean" tilewidth="16" tileheight="16" tilecount="784" columns="28">
 <image source="tileset-pixean.png" width="448" height="448"/>
 <tile id="24">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.181818" y="0.363636">
    <polygon points="0,0 0,15.0909 15.4545,15.4545 15.4545,-0.181818"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="25">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.363636" y="0.181818">
    <polygon points="0,0 -0.181818,15.2727 15.2727,15.8182 15.6364,0"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="52">
  <objectgroup draworder="index" id="2">
   <object id="1" x="4.90909" y="0.727273">
    <polygon points="0,0 -0.181818,11.8182 4.90909,11.8182 6,9.63636 10.9091,9.45455 10.7273,3.45455 6.18182,3.09091 6,0.545455 4.90909,-0.363636"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="53">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.181818" y="4.18182">
    <polygon points="0,0 4.54545,-0.181818 5.09091,-3.63636 9.81818,-4.36364 10.9091,-2.54545 11.0909,-0.181818 15.6364,-0.181818 15.8182,5.09091 11.0909,5.63636 10.3636,8.36364 6.72727,8.90909 4.72727,7.63636 5.27273,5.81818 0.363636,6"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="54">
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.545455" y="4">
    <polygon points="0,0 4.36364,0 4.90909,-3.09091 9.81818,-3.81818 10.7273,8 5.27273,8.90909 4,8.18182 4.18182,5.63636 -0.363636,5.81818"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="87">
  <objectgroup draworder="index" id="2">
   <object id="1" x="1.27273" y="5.81818"/>
  </objectgroup>
 </tile>
 <tile id="253">
  <objectgroup draworder="index" id="2">
   <object id="1" x="21.4545" y="8.90909"/>
  </objectgroup>
 </tile>
 <tile id="254">
  <objectgroup draworder="index" id="2">
   <object id="1" x="8.72727" y="5.09091"/>
  </objectgroup>
 </tile>
 <tile id="255">
  <objectgroup draworder="index" id="2">
   <object id="5" x="-5.81818" y="7.63636"/>
  </objectgroup>
 </tile>
</tileset>
