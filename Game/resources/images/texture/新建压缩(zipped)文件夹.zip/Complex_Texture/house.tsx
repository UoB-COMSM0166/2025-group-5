<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="house" tilewidth="16" tileheight="16" tilecount="35" columns="7">
 <image source="house.png" width="122" height="80"/>
</tileset>
