<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Outdoor_Decor_Free" tilewidth="16" tileheight="16" tilecount="84" columns="7">
 <image source="Outdoor_Decor_Free.png" width="112" height="192"/>
 <tile id="46">
  <objectgroup draworder="index" id="2">
   <object id="1" x="5.81818" y="14.7273">
    <polygon points="0,0 -1.63636,-1.81818 -1.63636,-4.72727 -0.181818,-5.81818 0.181818,-9.45455 1.27273,-11.6364 1.27273,-14.1818 3.45455,-14.3636 4.18182,-12 5.09091,-11.2727 4.36364,-9.63636 5.09091,-6.18182 7.27273,-4.90909 7.27273,-1.81818 5.27273,0.181818"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
