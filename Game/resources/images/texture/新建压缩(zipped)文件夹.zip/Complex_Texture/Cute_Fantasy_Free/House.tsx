<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="House" tilewidth="16" tileheight="16" tilecount="35" columns="5">
 <image source="House.png" width="80" height="112"/>
</tileset>
